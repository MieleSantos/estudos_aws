def log(message: str):
    print(f"Log de execução: {message}")
